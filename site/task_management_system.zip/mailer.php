<?php
require __DIR__ . '/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendTaskEmail($toEmail, $toName, $taskTitle, $description, $deadline) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'sammainah98@gmail.com';
        $mail->Password = 'vyyh grxj hmsa mtzm';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        
        // Enable debugging
        $mail->SMTPDebug = 0;
        $mail->Debugoutput = '';

        // Recipients
        $mail->setFrom('twizard720@gmail.com', 'Task Manager System');
        $mail->addAddress($toEmail, $toName);

        // Content
        $mail->isHTML(false);
        $mail->Subject = "New Task: $taskTitle";
        $mail->Body = "Hello $toName,\n\nYou've been assigned:\n\nTask: $taskTitle\nDescription: $description\nDeadline: $deadline\n\nLogin to update status.\n\n- Task Manager";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Email send failed: {$mail->ErrorInfo}");
        return false;
    }
}