<link rel="stylesheet" href="assets/style.css">
<?php
session_start();
require_once 'classes/User.php';

$userClass = new User();

$email = $_POST['email'];
$password = $_POST['password'];

$user = $userClass->getUserByEmail($email);

if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['name'] = $user['name'];
    header("Location: dashboard.php");
    exit();
} else {
    header("Location: index.php?error=Invalid credentials");
    exit();
}
