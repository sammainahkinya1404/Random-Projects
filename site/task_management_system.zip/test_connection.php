<!-- <?php
require 'db.php';

$db = new Database();
$conn = $db->connect();

if ($conn) {
    echo "Connected to MySQL via PDO!";
}
?> -->
