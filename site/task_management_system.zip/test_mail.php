<?php
require_once 'mailer.php';

$ok = sendTaskEmail('kinyanjuisamson1404@gmail.com', 'Test User', 'Test Task', 'This is just a test', '2025-07-20');

echo $ok ? '✅ Email sent!' : '❌ Email failed. Check logs.';
