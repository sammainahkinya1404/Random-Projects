<link rel="stylesheet" href="assets/style.css">
<?php
session_start();
require_once 'classes/User.php';

if (isset($_GET['id']) && $_GET['id'] != $_SESSION['user_id']) {
    $userClass = new User();
    $userClass->deleteUser($_GET['id']);
}

header("Location: users.php");
exit();

