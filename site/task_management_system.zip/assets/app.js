// Confirm before deleting a user/task
function confirmDelete() {
  return confirm("Are you sure you want to delete this item?");
}

// Dismiss alerts after 3s
window.onload = function () {
  const alertBox = document.querySelector(".alert");
  if (alertBox) {
    setTimeout(() => {
      alertBox.style.display = "none";
    }, 3000);
  }
};

// Disable submit buttons on submit to avoid double post
document.addEventListener("submit", function (e) {
  const btn = e.target.querySelector("button[type='submit']");
  if (btn) {
    btn.disabled = true;
    btn.innerText = "Processing...";
  }
});
