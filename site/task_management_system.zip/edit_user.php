<link rel="stylesheet" href="assets/style.css">
<?php
require_once 'classes/User.php';
$userClass = new User();

$id = $_GET['id'];
$user = $userClass->getUserById($id);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userClass->updateUser($id, $_POST['name'], $_POST['email'], $_POST['role']);
    header("Location: users.php");
    exit();
}
?>
<div class="form-wrapper">
<h2>Edit User</h2>
<form method="POST">
    Name: <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required><br><br>
    Email: <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required><br><br>
    Role:
    <select name="role">
        <option value="user" <?= $user['role'] == 'user' ? 'selected' : '' ?>>User</option>
        <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
    </select><br><br>

    <button type="submit">Update</button>
</form>
<a href="users.php">← Cancel</a>

</div>

<script src="assets/app.js"></script>
