<link rel="stylesheet" href="assets/tasks.css">
<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: index.php");
    exit();
}

require_once 'classes/Task.php';
$task = new Task();

$userId = $_SESSION['user_id'];
$tasks = $task->getTasksByUser($userId);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Tasks</title>
</head>
<body>
    <h2>Hello, <?= htmlspecialchars($_SESSION['name']) ?>!</h2>
    <div class="form-wrapper">
<h3>Your Assigned Tasks</h3>

    <?php if (empty($tasks)): ?>
        <p>No tasks assigned yet.</p>
    <?php else: ?>
        <form method="POST" action="update_status.php">
            <table border="1" cellpadding="5">
                <tr>
                    <th>Task</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Deadline</th>
                    <th>Update Status</th>
                </tr>
                <?php foreach ($tasks as $task): ?>
                    <tr>
                        <td><?= htmlspecialchars($task['title']) ?></td>
                        <td><?= htmlspecialchars($task['description']) ?></td>
                        <td><?= $task['status'] ?></td>
                        <td><?= $task['deadline'] ?></td>
                        <td>
                            <select name="status[<?= $task['id'] ?>]">
                                <option value="">-- no change --</option>
                                <option value="Pending">Pending</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Completed">Completed</option>
                            </select>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
            <br>
            <button type="submit">Update Status</button>
        </form>
    </div>
    
    <?php endif; ?>

    <br>
    <a href="dashboard.php">Back to Dashboard</a> |
    <a href="logout.php">Logout</a>
    <script src="assets/app.js"></script>

</body>
</html>
