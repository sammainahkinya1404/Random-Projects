<link rel="stylesheet" href="assets/style.css">
<?php
session_start();
$error = $_GET['error'] ?? '';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login - Task Manager</title>
</head>
<body>
    <div class="form-wrapper">

      <h2>Login</h2>
    <?php if ($error): ?>
        <p style="color: red"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    <form method="POST" action="login.php">
        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>

        <label>Password:</label><br>
        <input type="password" name="password" required><br><br>

        <button type="submit">Login</button>

    </form>
        <p>Don't have an account? <a href="register.php">Register here</a></p>

    </div>
<script src="assets/app.js"></script>


</body>
</html>
