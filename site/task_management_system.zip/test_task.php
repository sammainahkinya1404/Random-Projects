<?php
require_once 'classes/Task.php';

$task = new Task();

// Assign a new task to user with ID 1
$task->assignTask("Finish report", "Write the end-of-month financial report", 1, "2025-07-15");

// Update task status to Completed
$task->updateTaskStatus(1, "Completed");

// Get tasks for user ID 1
$myTasks = $task->getTasksByUser(1);

// Show all tasks (admin view)
$allTasks = $task->getAllTasks();

echo "<h3>User Tasks</h3><pre>";
print_r($myTasks);
echo "</pre>";

echo "<h3>All Tasks</h3><pre>";
print_r($allTasks);
echo "</pre>";
?>
