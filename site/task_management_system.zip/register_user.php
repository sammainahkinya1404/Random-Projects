<link rel="stylesheet" href="assets/style.css">
<?php
require_once 'classes/User.php';

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];

$userClass = new User();
$existing = $userClass->getUserByEmail($email);

if ($existing) {
    header("Location: register.php?error=Email already exists");
    exit();
}

$success = $userClass->addUser($name, $email, $password);

if ($success) {
    header("Location: index.php?message=Registration successful. Please log in.");
} else {
    header("Location: register.php?error=Something went wrong");
}
