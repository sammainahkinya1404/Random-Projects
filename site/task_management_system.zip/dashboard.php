<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require_once 'classes/Task.php';
$taskClass = new Task();
$taskCounts = [];

if ($_SESSION['role'] === 'user') {
    $userTasks = $taskClass->getTasksByUser($_SESSION['user_id']);
    $taskCounts = [
        'Pending' => 0,
        'In Progress' => 0,
        'Completed' => 0
    ];

    foreach ($userTasks as $task) {
        $status = $task['status'];
        if (isset($taskCounts[$status])) {
            $taskCounts[$status]++;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>
  <link rel="stylesheet" href="assets/tasks.css">
<link rel="stylesheet" href="assets/dashboard.css">
</head>
<body>

<div class="dashboard-wrapper">
  <h2>Welcome, <?= htmlspecialchars($_SESSION['name']) ?>!</h2>
  <p>Your role: <?= htmlspecialchars($_SESSION['role']) ?></p>

  <?php if ($_SESSION['role'] === 'admin'): ?>
    <a href="admin_panel.php">Go to Admin Panel</a><br>
  <?php else: ?>
    <a href="my_tasks.php">View My Tasks</a><br>
    <div id="task-reminder" class="reminder-box"></div>
    <script>
      const taskStats = <?= json_encode($taskCounts) ?>;

      const reminderBox = document.getElementById('task-reminder');
      const total = Object.values(taskStats).reduce((sum, val) => sum + val, 0);

      if (total === 0) {
        reminderBox.innerHTML = "<p>You have no tasks assigned yet.</p>";
      } else {
        reminderBox.innerHTML = `
          <p><strong>Task Summary:</strong></p><br>
            <p><strong>Pending</strong>: ${taskStats['Pending']}
            <p><strong>In Progress</strong>: ${taskStats['In Progress']}</p>
            <p><strong>Completed</strong>: ${taskStats['Completed']}</p>
        `;
      }
    </script>
  <?php endif; ?>

  <a href="logout.php">Logout</a>
</div>

</body>
</html>
