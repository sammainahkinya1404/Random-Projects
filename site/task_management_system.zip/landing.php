<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Task Management System</title>
  <link rel="stylesheet" href="assets/landing.css">
</head>
<body>

<div class="landing-container">
  <div class="landing-content">
    <h1>Cytonn Task Management System</h1>
    <p>Organize. Assign. Track. Stay Productive.</p>
    <div class="landing-buttons">
      <a href="login.php" class="btn">Login</a>
      <a href="register.php" class="btn btn-secondary">Register</a>
    </div>
  </div>
</div>

</body>
</html>
