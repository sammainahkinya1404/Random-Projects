<?php

require_once __DIR__ . '/../db.php';

class Task {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }

    //Assign a task to a user
    public function assignTask($title, $description, $assignedTo, $deadline) {
        $stmt = $this->conn->prepare(
            "INSERT INTO tasks (title, description, assigned_to, deadline) VALUES (?, ?, ?, ?)"
        );
        return $stmt->execute([$title, $description, $assignedTo, $deadline]);
    }

    //Get tasks for a specific user
    public function getTasksByUser($userId) {
        $stmt = $this->conn->prepare("SELECT * FROM tasks WHERE assigned_to = ?");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Update task status
    public function updateTaskStatus($taskId, $newStatus) {
        $stmt = $this->conn->prepare("UPDATE tasks SET status = ? WHERE id = ?");
        return $stmt->execute([$newStatus, $taskId]);
    }

    // Get all tasks
    public function getAllTasks() {
        $stmt = $this->conn->query("
            SELECT tasks.*, users.name AS assigned_user 
            FROM tasks 
            JOIN users ON tasks.assigned_to = users.id
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
