<?php
require_once 'classes/User.php';

$user = new User();

// Add a new user
$user->addUser("Jane Doe", "jane@example.com", "secret123", "admin");

// Show all users
$users = $user->getAllUsers();
echo "<pre>";
print_r($users);
echo "</pre>";
?>
